
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'btc2628',
  applicationName: 'cryptobara',
  appUid: 'gqWw52BkTCTNB69smm',
  orgUid: '69f37fdc-5383-4141-95e0-90fbe47b64e1',
  deploymentUid: '7ef4017e-f6c6-410e-a88f-2b1fe744b113',
  serviceName: 'cryptobara',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'cryptobara-dev-server', timeout: 6 };

try {
  const userHandler = require('./server/handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.server, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}