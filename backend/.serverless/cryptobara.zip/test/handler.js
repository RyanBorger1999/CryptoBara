'use strict';
const username = 'cryptobara';
const hostName = 'cryptobara.c9f7uln9tswm.us-east-1.rds.amazonaws.com';
const portNumber = 3333;
const databaseName = 'postgres';
const password = 'crypt0Bara';

const PgConnection = require('postgresql-easy');
var querystring = require('querystring');

const pg = new PgConnection({

  user: username,
  host: hostName,
  database: databaseName,
  password: password,
  port: portNumber,
  
});


module.exports.test = async (event, context, callback) => {

  context.callbackWaitsForEmptyEventLoop = false;

  if (event.httpMethod == 'GET'){
    console.log("test");
    const response = pg.getById('test', 40).then(res => {
      console.log(response);
      console.log(res);
      // callback(null, {
      //   statusCode: 200,
      //   headers: {
      //     "Access-Control-Allow-Headers" : "Content-Type",
      //     "Access-Control-Allow-Origin": "http://localhost:3000",
      //     "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
      //   },
      //   body: JSON.stringify(res, null, 2)

      // })
    }).catch(error => {

      console.log(error);

      callback(null, {

        statusCode: error.statusCode || 500,
        body: 'Error: Could not find Order: ' + error

      })
    });
  } else if (event.httpMethod == 'POST') {
    console.log(event.body);
    const data = JSON.parse(event.body);
    await pg.insert('server', 
    {
      id: data["id"]
    }).then(res => {

      callback(null, {
        
        statusCode: 200,
        body: JSON.stringify(res, null, 2)

      })
    }).catch(error => {

      console.log(error);

      callback(null, {

        statusCode: error.statusCode || 500,
        body: 'Error: Could not find Server: ' + error

      })
    });
  }
};